CPI price collection - files to run in Dataiku

Install: pip install "scrapling[fetchers]" openpyxl pillow requests

Order of a daily run (all from the project root, output in data/runs/<date>_daily):
 1. scripts/scrapling_search.py carrefour <run_dir>      barcode search
 2. scripts/scrapling_search.py lulu <run_dir>
 3. scripts/scrapling_category.py <run_dir>              bulk categories (no-barcode lines)
 4. scripts/combine_run.py <run_dir>
 5. scripts/name_live.py <run_dir>                       live name search
 6. scripts/product_panel.py update/series ...           product history
 7. scripts/panel_run.py <run_dir> <started>             rows (set CPI_CATALOGUE_JSON for catalogue fill)
Export: scripts/export_basket_csv.py -> Dataiku CSV (44 columns + cpi_group)

Not in the zip (kept in the portal database): pins, product history, weights (Book1), catalogue.json.
Recipes under dataiku/ were not re-checked against the latest changes.
